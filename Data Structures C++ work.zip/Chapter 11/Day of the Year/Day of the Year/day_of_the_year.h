#pragma once

#ifndef DAY_OF_THE_YEAR_H
#define DAY_OF_THE_YEAR_H

class DayOfYear
{
private:
	//Member variables
	int julianDay;

public:
	DayOfYear() {}; //Default constructor

	static const int MonthDays[];
	static const std::string MonthName[];

	//Member functions
	//print the day in the month-day format
	void print();
	void setDay(int day) { this->julianDay = day; }
};

//Put days of each month into an array
const int DayOfYear::MonthDays[] = { 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };

//Put the name of each month into an array
const std::string DayOfYear::MonthName[] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

//Convert and print the day of year
void DayOfYear::print()
{
	int month = 0;

	while (DayOfYear::MonthDays[month] < julianDay)
		month = (month + 1) % 12;

		//Display the month and day
		if (month == 0)
		{
			std::cout << "January " << julianDay << std::endl;
		}
		else
		{
			std::cout << DayOfYear::MonthName[month] << " " << julianDay - DayOfYear::MonthDays[month - 1] << std::endl;
		}
}

#endif // !DAY_OF_THE_YEAR_H