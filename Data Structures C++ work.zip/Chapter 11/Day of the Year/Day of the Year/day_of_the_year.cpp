/*Day of the Year
This is a program that takes an integer representing a day of the year and translates it to a string consisting of the month followed by the day of the
month based on user input.
Benjamin Costello
*/


#include <iostream>
#include <string>
#include "day_of_the_year.h"


int main()
{
	DayOfYear dayYear; //DayOfYear class object

	int day;

	//Get the day number from the user
	std::cout << "Enter a number to be converted into a month and day: ";
	std::cin >> day;

	//User input validation - for negative numbers and numbers larger than a single year
	if (day < 0 || day > 365)
	{
		std::cout << "Number entered must be valid. Choose between 0-365." << std::endl;
		system("pause");
		return 0;
	}

	//Send the data to the print() function
	dayYear.setDay(day);
	dayYear.print();

	system("pause");

	return 0;
}