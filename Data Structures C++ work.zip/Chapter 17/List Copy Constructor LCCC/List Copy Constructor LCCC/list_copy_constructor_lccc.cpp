/*List Copy Constructor
This program modifies the Simple Linked List Class by adding a copy constructor.
Benjamin Costello
*/


#include <iostream>
using namespace std;


//node class
class ListNode
{
public:
	ListNode(double v, ListNode *p)
	{
		value = v; next = p;
	}
private:
	double value;
	ListNode *next;
	friend class LinkedList; // LinkedList  has friend status	
};

//linked list class
class LinkedList
{
public:
	LinkedList(LinkedList &otherList);
	void add(double x);
	bool isMember(double x);
	LinkedList() { head = NULL; }
	~LinkedList();            //LinkedList destructor
private:
	ListNode * head;
	static ListNode *makeCopy(ListNode *pList);
};

//makeCopy to copy the original list
ListNode  *LinkedList::makeCopy(ListNode *pList)
{
	if (pList == NULL)
	{
		return NULL;
	}
	else
	{
		return new ListNode(pList->value, makeCopy(pList->next));
	}
}

//user defined copy constructor
LinkedList::LinkedList(LinkedList &otherList)
{
	head = makeCopy(otherList.head);
}

//add function
void LinkedList::add(double x)
{
	head = new ListNode(x, head);
}

//isMember function
bool LinkedList::isMember(double x)
{
	ListNode *p = head; // Use p to walk through list
	while (p != NULL)
	{
		if (p->value == x) return true;
		else
			p = p->next;
	}
	// List is exhausted without finding x
	return false;
}

//Destructor for the LinkedList class
LinkedList::~LinkedList()
{
	while (head != 0)
	{
		ListNode * p = head;
		head = head->next;
		delete p;
	}
}

int main()
{
	// Explain program to user
	cout << "This program constructs a list of numbers, then constructs a copy, and allows "
		<< "\nto check if various numbers are on copy of the list.";

	// Create empty list
	LinkedList otherList;
	// Get input from user and add them to list
	cout << "\nEnter 5 numbers: ";
	for (int k = 1; k <= 5; k++)
	{
		double x;
		cin >> x;
		otherList.add(x);
	}

	// Make a copy using copy constructor  
	LinkedList list2(otherList);

	// Allow user to test membership
	for (int k = 1; k <= 5; k++)
	{
		double x;
		cout << "Enter a number to test membership for: ";
		cin >> x;
		if (list2.isMember(x))
			cout << "\n" << x << " is on the copy of the list." << endl;
		else
			cout << "\n" << x << " is not on the copy of the list." << endl;
	}
	system("pause");
	return 0;
}