/*List Copy Constructor
This program modifies the Simple Linked List Class by adding a copy constructor.
Benjamin Costello
*/


#include <iostream>
using namespace std;


class LinkedList
{
protected:
	struct ListNode
	{
		double value;
		ListNode *next;
		ListNode(double value1, ListNode *next1 = nullptr)
		{
			value = value1;
			next = next1;
		}
	};
	ListNode *head; //head pointer for our list
public:
	LinkedList() { head = NULL; } //default constructor
	~LinkedList();
	void add(double x);
	bool isMember(double x);

	LinkedList(const LinkedList& otherList) //user defined copy constructor
	{ 
		if (otherList.head == NULL)
		{
			head = NULL;
		}
		else
		{
			head = new ListNode(otherList.head->value);
			ListNode *current = head;
			ListNode *otherListHead = otherList.head;
			ListNode *currentotherList = otherListHead;
			while (currentotherList->next != NULL) {
				current->next = new ListNode(currentotherList->next->value);
				currentotherList = currentotherList->next;
				current = current->next;
			}
		}
	}; 
};

//add function to add a new node containing x to the front (head) of the list
void LinkedList::add(double x)
{
	if (head == NULL)
	{
		head = new ListNode(x);
	}
	else
	{
		head = new ListNode(x, head);
	}
}

//isMember function tests to see if the list contains a node with the value x
bool LinkedList::isMember(double x)
{
	ListNode *ptr = head; //start at the front of the list
	while (ptr != NULL)
	{
		if (ptr->value == x)
		{
			return true;
		}
		ptr = ptr->next;
	}
	return false;
}

//destructor to deallocate memory used by the list
LinkedList::~LinkedList()
{
	ListNode *ptr = head; //start at the front of the list
	while (ptr != NULL)
	{
		ListNode *garbage = ptr;
		ptr = ptr->next;
		delete garbage;
	}
}

int main()
{
	LinkedList list; //object for LinkedList class

	LinkedList *copy = new LinkedList();
	LinkedList otherList = list; //copy constructor called here

	//Get input from the user and add the numbers to the list
	cout << "\nEnter 5 numbers: ";
	for (int i = 1; i <= 5; i++)
	{
		double x;
		cin >> x;
		list.add(x);
	}

	//Allow user to test membership
	for (int i = 1; i <= 5; i++)
	{
		double x;
		cout << "Enter a number to test for membership in the list: ";
		cin >> x;
		if (list.isMember(x))
		{
			cout << "\n" << x << " is in the list." << endl;
		}
		else
		{
			cout << "\n" << x << " is not in the list." << endl;
		}
	}

	

	system("pause");
	return 0;
}