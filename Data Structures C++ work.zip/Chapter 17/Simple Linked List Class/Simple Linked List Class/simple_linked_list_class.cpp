/*Simple Linked List Class
This is a program using a simple linked list class with two member functions and a default constructor.
Benjamin Costello
*/


#include <iostream>
using namespace std;


class ListNode
{
public:
	ListNode(double v, ListNode *p)
	{
		value = v; next = p;
	}
private:
	double value;
	ListNode *next;
	friend class LinkedList; // LinkedList  has friend status
};
class LinkedList
{
private:
	ListNode * head;

public:
	LinkedList() { head = NULL; } //default constructor
	~LinkedList();
	void add(double x);
	bool isMember(double x);
};

//add function to add a new node containing x to the front (head) of the list
void LinkedList::add(double x)
{
	head = new ListNode(x, head);
}

//isMember function tests to see if the list contains a node with the value x
bool LinkedList::isMember(double x)
{
	ListNode *p = head; // Use p to walk through list
	while (p != NULL)
	{
		if (p->value == x) return true;
		else
			p = p->next;
	}
	// List is exhausted without finding x
	return false;
}

//destructor to deallocate memory used by the list
LinkedList::~LinkedList()
{
	ListNode *ptr = head; //start at the front of the list
	while (ptr != NULL)
	{
		ListNode *garbage = ptr;
		ptr = ptr->next;
		delete garbage;
	}
}

int main()
{
	LinkedList list; //object for LinkedList class
	//Get input from the user and add the numbers to the list
	cout << "\nEnter 5 numbers: ";
	for (int i = 1; i <= 5; i++)
	{
		double x;
		cin >> x;
		list.add(x);
	}

	//Allow user to test membership
	for (int i = 1; i <= 5; i++)
	{
		double x;
		cout << "Enter a number to test for membership in the list: ";
		cin >> x;
		if (list.isMember(x))
		{
			cout << "\n" << x << " is in the list." << endl;
		}
		else
		{
			cout << "\n" << x << " is not in the list." << endl;
		}
	}
	system("pause");
	return 0;
}