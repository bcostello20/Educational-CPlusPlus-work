/*
Augmented Simple Binary Search Tree Class - using PC 2, 3 and 4
This is a class for implementing a simple binary search tree capable of storing numbers.
Benjamin Costello
*/


#include <iostream>
#include <vector>
#include "binary_tree.h"
using namespace std;

//insert function which inserts a number into a subtree of tree
void BinaryTree::insert(BtreeNode * &tree, double x)
{
	// If the tree is empty, make a new node and make it 
	// the root of the tree.
	if (!tree)
	{
		tree = new BtreeNode(x);
		return;
	}
	// If num is already in tree: return.
	if (tree->value == x)
		return;

	// The tree is not empty: insert the new node into the 
	// left or right subtree.
	if (x < tree->value)
		insert(tree->left, x);
	else
		insert(tree->right, x);
}

//search function to see if a value is already present in the tree, and if so, returns true
bool BinaryTree::search(double x, BtreeNode *t)
{
	while (t)
	{
		if (t->value == x)
			return true;
		else if (x < t->value)
			return search(x, t->left);
		else
			return search(x, t->right);
	}
	return false;
}

//fillInOrder function passed by a vector, fills v with the list of numbers in order, stored in the tree
void BinaryTree::fillInorder(vector <double> & v, BtreeNode *tree)
{
	if (tree)
	{
		fillInorder(v, tree->left);
		v.push_back(tree->value);
		fillInorder(v, tree->right);
	}
}

int BinaryTree::size(BtreeNode *leaf) const
{
	if (leaf == NULL) { //This node doesn't exist. Therefore there are no nodes in this 'subtree'
		return 0;
	}
	else { //Add the size of the left and right trees, then add 1 (which is the current node)
		return size(leaf->left) + size(leaf->right) + 1;
	}
}

int BinaryTree::leafCount(BtreeNode *node)
{
	if (node == NULL)
		return 0;
	if (node->left == NULL && node->right == NULL)
		return 1;
	else
		return leafCount(node->left) +
		leafCount(node->right);
}

int BinaryTree::height(BtreeNode *node)
{
	if (root == NULL)
		return 0;
	else
	{
		//Compute the depth of each subtree
		int lDepth = height(node->left);
		int rDepth = height(node->right);

		//Use the larger one
		if (lDepth > rDepth)
			return(lDepth + 1);
		else return(rDepth + 1);
	}
}

int main()
{
	system("pause");
	return 0;
}