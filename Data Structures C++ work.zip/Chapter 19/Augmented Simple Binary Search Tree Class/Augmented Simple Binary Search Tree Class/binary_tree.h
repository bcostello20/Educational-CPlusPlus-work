#pragma once
#ifndef BINARY_TREE_H
#define BINARY_TREE_H
#include <iostream>
#include <vector>
using namespace std;


class BinaryTree
{
private:
	class BtreeNode //This class is used to build the tree
	{
		friend class BinaryTree;
		double value;
		BtreeNode *left;
		BtreeNode *right;
		BtreeNode(double value1, BtreeNode *left1 = NULL, BtreeNode *right1 = NULL)
		{
			value = value1;
			left = left1;
			right = right1;
		}
	};
	BtreeNode *root; //Tree root pointer
	void insert(BtreeNode *&, double);
	bool search(double, BtreeNode *);
	void fillInorder(vector <double> & v, BtreeNode *);
	int size(BtreeNode *leaf) const;
	int leafCount(BtreeNode *node);
	int height(BtreeNode *node);

public:
	//Constructor
	BinaryTree() { root = NULL; }
	//Member functions
	void insert(double x)
	{
		insert(root, x);
	}
	bool search(double x)
	{
		return search(x, root);
	}
	void inorder(vector <double> & v)
	{
		fillInorder(v, root);
	}
};
#endif //BINARY_TREE_H