#pragma once
#ifndef VOWELS_AND_CONSONANTS_H
#define VOWELS_AND_CONSONANTS_H

class VowelsandConsonants
{
public:
	VowelsandConsonants() {}; //Default constructor

	char userString[61]; //The string entered by the user

	//Member function(s)
	int numberOfVowels(const char *userString);
	int numberOfConsonants(const char *userString);

	void getUserString()
	{
		std::cout << "Enter a word or brief sentence fewer than 60 characters: ";
		std::cin.getline(userString, 61);
		//std::cout << "in getUserString string equals " << userString << std::endl; DEBUGGING
	}

	int getVowels() //Store the amount of vowels and return it to the .cpp
	{
		return vowels;
	}

	int getConsonants() //Store the amount of consonants and return it to the .cpp
	{
		return consonants;
	}

	void Reset() //Reset the variables to 0 to avoid incorrect numbers when running the functions again
	{
		vowels = consonants = 0;
	}

private:
	//Member variable(s)
	int vowels = 0, consonants = 0;
};


#endif //VOWELS_AND_CONSONANTS_H
