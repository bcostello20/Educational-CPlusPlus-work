/*Vowels and Consonants

This is a program that asks the user to enter a string and then displays a menu:
A) Count the number of vowels in the string
B) Count the number of consonants in the string
C) Count both the vowels and consonants in the string
D) Enter another string
E) Exit the program

Benjamin Costello
*/

#include <iostream>
#include <string>
#include "vowels_and_consonants.h"


int main()
{
	VowelsandConsonants VaC; //Class object

	char choice;
	choice = NULL;

	//Call the function to ask the user to enter a string
	VaC.getUserString();

	while (choice != 'E')
	{
		//Show the menu choices
		std::cout << std::endl;
		std::cout << "A) Count the number of vowels in the string" << std::endl;
		std::cout << "B) Count the number of consonants in the string" << std::endl;
		std::cout << "C) Count both the vowels and consonants in the string" << std::endl;
		std::cout << "D) Enter another string" << std::endl;
		std::cout << "E) Exit the program" << std::endl;
		std::cout << std::endl;
		std::cout << "Enter your letter choice: ";
		std::cin >> choice;

		switch (choice) //Begin the actions to take based on the users letter choice
		{
		case 'A': case 'a': //Shows the number of vowels in the string
		{
			VaC.Reset();
			int resultA = VaC.numberOfVowels(VaC.userString);
			std::cout << std::endl;
			std::cout << "There are " << resultA << " vowels in this string." << std::endl;
			std::cout << std::endl;
			break;
		}
		case 'B': case 'b': //Shows the number of consonants in the string
		{
			//std::cout << "the string in case B is " << VaC.userString << std::endl; DEBUGGING
			int resultB = VaC.numberOfConsonants(VaC.userString);
			std::cout << std::endl;
			std::cout << "There are " << resultB << " consonants in this string." << std::endl;
			std::cout << std::endl;
			break;
		}
		case 'C': case 'c': //Shows the number of vowels and consonants together in the string
		{
			int resultC = VaC.getVowels() + VaC.getConsonants(); //Call the get functions from the .h and add the variables together
			std::cout << std::endl;
			std::cout << "There are " << resultC << " vowels and consonants together in this string." << std::endl;
			std::cout << std::endl;
			break;
		}
		case 'D': case 'd': //Asks the user for a new string
		{
			std::cout << std::endl;
			VaC.getUserString();
			std::cin.getline(VaC.userString, 61);
			break;
		}
		case 'E': case 'e': //Exits the program
		{
			return 0;
		}
		default:
		{
			//User input validation
			if (choice != 'A' || choice != 'a' || choice != 'B' || choice != 'b' || choice != 'C' || choice != 'c' || choice != 'D' || choice != 'd'

				|| choice != 'E' || choice != 'e')
			{
				std::cout << std::endl;
				std::cout << "Invalid input. Must chose one of A-E. Please try again.";
				std::cout << std::endl;
			}
		}
			break;
		}
	}
	system("pause");
	return 0;
}

int VowelsandConsonants::numberOfVowels(const char *userString)
{
	//std::cout << "the string now equals " << userString << std::endl; DEBUGGING
	for (int i = 0; userString[i] != '\0'; ++i) //Begin the for loop to count the number of vowels in the string
	{
		if (userString[i] == 'a' || userString[i] == 'e' || userString[i] == 'i' ||
			userString[i] == 'o' || userString[i] == 'u' || userString[i] == 'A' ||
			userString[i] == 'E' || userString[i] == 'I' || userString[i] == 'O' ||
			userString[i] == 'U')
		{
			++vowels;
		}
	}
	return vowels; //Return the amount of vowels
}

int VowelsandConsonants::numberOfConsonants(const char *userString)
{
	int i = 0;
	while (userString[i] != '\0') //Begin the for loop to count the number of consonants in the string
	{
		//std::cout << userString[i] << std::endl; DEBUGGING
		if (userString[i] != 'a' && userString[i] != 'e' && userString[i] != 'i' &&
			userString[i] != 'o' && userString[i] != 'u' && userString[i] != 'A' &&
			userString[i] != 'E' && userString[i] != 'I' && userString[i] != 'O' &&
			userString[i] != 'U')
		{
			++consonants;
		}
		++i;
	}
	return consonants; //Return the amount of consonants
}