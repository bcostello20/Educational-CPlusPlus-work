/*Recursive Array Sum
This is a program that accepts two arguments, an array of integers, and a number indicating the number of elements in the array.
The function will recursively calculate the sum of all the numbers in the array. The program will ask the user to enter an array of numbers and prints - 
its sum.
Benjamin Costello
*/

#include <iostream>
using namespace std;

//Function prototype
int addNumbers(int array[], int start, int length);

int main()
{
	const int MAX_SIZE = 100; //The array can have a max size of 100 elements
	int array[MAX_SIZE];
	int num, arraySum;

	//Get the size of the array from the user
	cout << "Enter the size of the array: ";
	cin >> num;

	//Get the elements in the array
	cout << "Enter elements in the array: ";
	for (int i = 0; i < num; i++)
	{
		cin >> array[i]; //For loop to step through the array placing the elements
	}

	arraySum = addNumbers(array, 0, num); //Call the addNumbers function passing the proper arguments
	cout << "The sum of the array elements is: " << arraySum << endl; //Display the sum of the array elements

	system("pause");
	return 0;
}

//Recursively find the sum of the elements in the array
int addNumbers(int array[], int start, int length)
{
	if (start >= length)
	{
		return 0;
	}
	else
	{
		return (array[start] + addNumbers(array, start + 1, length));
	}
}