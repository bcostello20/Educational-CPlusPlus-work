/*Prefix to Postfix
This is a program that reads prefix expressions and converts them to postfix. Each prefix expression is entered on a new line. The program -
will keep reading prefix expressions and converting them to postfix until a blank line is entered.
Benjamin Costello
*/


#include <iostream>
#include <string>
#include <sstream>
#include <cstdlib>
using namespace std;

//Function prototype
void preToPost(string preString, string &postString);

int main()
{
	string input;
	string postString;
	//Get the user to enter the prefix expressions
	cout << "Enter prefix expressions to convert to postfix." << endl
		<< "Press enter after each expression," << endl
		<< "and press enter on a blank line to quit." << endl;
	cout << "Enter a prefix expression to convert: ";
	getline(cin, input);
	//while (input.size() != 0)
	//{
		//Convert to postfix
		//cout << "The input is: " << input << " and the postString is: " << postString << endl; DEBUGGING
		preToPost(input, postString);
	//}

	system("pause");
	return 0;
}

void preToPost(string preString, string &postString)
{
	char ch = preString.front();
	//preString.erase(preString[0]);
	if (ch == '+' || ch == '-' || ch == '*' || ch == '/')
	{
		//cout << "ch is: " << ch << endl DEBUGGING;
		for (int i = 0; i < preString.size(); i++)
		{
			postString = (postString + preString[i+1]) + ch;
		}
		//postString = postString + preString[2] + preString[1] + ch; //concatenate
	}
	else
	{
		//recursion to convert 1st
		preToPost(preString, postString);
		//recursion to convert 2nd
		preToPost(preString, postString);
		//concatenate the operator
		postString = postString + ch;
	}
	cout << "Final postString is: " << postString << endl;
}