/*Team Project 2 - Priority Queues
This is a program to simulate how the computer processses tasks from a priority queue.
Benjamin Costello & Edgard Flores
*/

#include <iostream>
#include <queue>
#include <stack>
#include <windows.h>
using namespace std;

HANDLE screen = GetStdHandle(STD_OUTPUT_HANDLE);

static int choice;

//Function prototypes
void showPQ(priority_queue <int> queue);
void reverseQueue(priority_queue <int> queue);
template <class Q>
void clearQueue(Q & q);
void removeNumber(priority_queue <int> queue);
void addNumber(priority_queue <int> queue);
void ORDER66(priority_queue <int> queue);


int main()
{
	int number; //User number entered
	char pick; //User pick for menu choices

	priority_queue <int> theQueue;
	priority_queue <int> tempQueue; tempQueue = theQueue; //set a temporary queue to the values of theQueue

	//Get the 4 numbers from the user
	for (int i = 0; i < 4; i++)
	{
		cout << "Enter a number to be added to the queue: ";
		cin >> number;
		cout << endl;
		theQueue.push(number);
		tempQueue.push(number);
	}

	cout << "The priority queue theQueue is : ";
	showPQ(theQueue);

	cout << "\ntheQueue.size() : " << theQueue.size();
	cout << "\ntheQueue.top() : " << theQueue.top();

	//cout << "\ntheQueue.pop() : ";
	//theQueue.pop();
	//showPQ(theQueue);
	cout << endl << endl;

	//The menu
	int choice; //User menu choice
	cout << "~~~Menu Choices~~~" << endl;
	cout << "1. Reverse order of queue." << endl;
	cout << "2. Clear the priority queue." << endl;
	cout << "3. Remove a number from the queue." << endl;
	cout << "4. Add a number to the queue." << endl;
	cout << "5. Exit the program.\n" << endl;
	cout << "6. Execute Order 66.\n" << endl;
	cout << "Enter a number between 1 and 6 from the above choices: ";
	cin >> choice;

	if (choice < 1 || choice > 6)
	{
		cout << endl;
		cout << "Invalid menu choice, please try again.\n" << endl;

		cout << "~~~Menu Choices~~~" << endl;
		cout << "1. Reverse order of queue." << endl;
		cout << "2. Clear the priority queue." << endl;
		cout << "3. Remove a number from the queue." << endl;
		cout << "4. Add a number to the queue." << endl;
		cout << "5. Exit the program.\n" << endl;
		cout << "6. Execute Order 66.\n" << endl;
		cout << "Enter a number between 1 and 6 from the above choices: ";
		cin >> choice;
	}
	if (choice == 1)
	{
		cout << endl;
		cout << "The priority queue in reverse order is:" << endl;
		reverseQueue(tempQueue);
		cout << endl << endl;
		//Would the user like to pick another choice from the menu?
		cout << "Would you like to pick another menu choice? (Y/N): ";
		cin >> pick;
	}
	if (choice == 2)
	{
		cout << endl;
		cout << "The priority queue cleared is: " << endl;
		clearQueue(theQueue);
		showPQ(theQueue);
		cout << "It is now a blank line.\n" << endl;
		//Would the user like to pick another choice from the menu?
		cout << "Would you like to pick another menu choice? (Y/N): ";
		cin >> pick;
	}
	if (choice == 3)
	{
		cout << endl;
		cout << "The first number in the queue has been removed.\n";
		removeNumber(theQueue);
		//Would the user like to pick another choice from the menu?
		cout << endl << endl;
		cout << "Would you like to pick another menu choice? (Y/N): ";
		cin >> pick;
	}
	if (choice == 4)
	{
		cout << endl;
		addNumber(theQueue);
		cout << endl << endl;
		cout << "Would you like to pick another menu choice? (Y/N): ";
		cin >> pick;
	}
	if (choice == 5)
	{
		cout << endl;
		cout << "***User has ended the program.***" << endl;
		system("pause");
		return 0;
	}

	if (choice == 6)
	{
		cout << endl;
		ORDER66(theQueue);
		cout << "***The Emperor has ended the Jedi Order.***" << endl;
		system("pause");
		return 0;
	}

	//Would the user like to pick another choice from the menu?
	/*char pick;
	cout << "Would you like to pick another menu choice? (Y/N): ";
	cin >> pick;*/

	//pick validation
	if (pick != 'Y' && pick != 'y' && pick != 'N' && pick != 'n')
	{
		cout << endl;
		cout << "Invalid pick, please enter a correct character.\n" << endl;

		cout << "Would you like to pick another menu choice? (Y/N): " << endl;
		cin >> pick;
	}
	if (pick == 'N' || pick == 'n')
	{
		cout << endl;
		cout << "***User has ended the program.***" << endl;
		system("pause");
		return 0;
	}

	while (pick == 'Y' || pick == 'y')
	{
		cout << "~~~Menu Choices~~~" << endl;
		cout << "1. Reverse order of queue." << endl;
		cout << "2. Clear the priority queue." << endl;
		cout << "3. Remove a number from the queue." << endl;
		cout << "4. Add a number to the queue." << endl;
		cout << "5. Exit the program.\n" << endl;
		cout << "6. Execute Order 66.\n" << endl;
		cout << "Enter a number between 1 and 6 from the above choices: ";
		cin >> choice;

		while (choice < 1 || choice > 6)
		{
			cout << endl;
			cout << "Invalid menu choice, please try again.\n" << endl;

			cout << "~~~Menu Choices~~~" << endl;
			cout << "1. Reverse order of queue." << endl;
			cout << "2. Clear the priority queue." << endl;
			cout << "3. Remove a number from the queue." << endl;
			cout << "4. Add a number to the queue." << endl;
			cout << "5. Exit the program.\n" << endl;
			cout << "6. Execute Order 66.\n" << endl;
			cout << "Enter a number between 1 and 6 from the above choices: ";
			cin >> choice;
		}
		if (choice == 1)
		{
			cout << endl;
			cout << "The priority queue in reverse order is:" << endl;
			reverseQueue(tempQueue);
			cout << endl << endl;
			cout << "Would you like to pick another menu choice? (Y/N): ";
			cin >> pick;
			if (pick == 'N' || pick == 'n')
			{
				cout << endl;
				cout << "***User has ended the program.***" << endl;
				system("pause");
				return 0;
			}
		}
		if (choice == 2)
		{
			cout << endl;
			cout << "The priority queue cleared is: " << endl;
			clearQueue(theQueue);
			showPQ(theQueue);
			cout << "It is now a blank line.\n" << endl;
			cout << "Would you like to pick another menu choice? (Y/N): ";
			cin >> pick;
			if (pick == 'N' || pick == 'n')
			{
				cout << endl;
				cout << "***User has ended the program.***" << endl;
				system("pause");
				return 0;
			}
		}
		if (choice == 3)
		{
			cout << endl;
			cout << "The first number in the queue has been removed.\n";
			removeNumber(tempQueue);
			cout << endl << endl;
			cout << "Would you like to pick another menu choice? (Y/N): ";
			cin >> pick;
			if (pick == 'N' || pick == 'n')
			{
				cout << endl;
				cout << "***User has ended the program.***" << endl;
				system("pause");
				return 0;
			}
		}
		if (choice == 4)
		{
			cout << endl;
			addNumber(tempQueue);
			cout << endl << endl;
			cout << "Would you like to pick another menu choice? (Y/N): ";
			cin >> pick;
			if (pick == 'N' || pick == 'n')
			{
				cout << endl;
				cout << "***User has ended the program.***" << endl;
				system("pause");
				return 0;
			}
		}
		if (choice == 5)
		{
			cout << endl;
			cout << "***User has ended the program.***" << endl;
			system("pause");
			return 0;
		}
		if (choice == 6)
		{
			cout << endl;
			ORDER66(tempQueue);
			cout << "***The Empreror has ended the Jedi Order.***" << endl;
			system("pause");
			return 0;
		}
	}
	system("pause");
	return 0;
}

//showPQ function to display what's in the priority queue
void showPQ(priority_queue <int> queue)
{
	priority_queue <int> g = queue;
	while (!g.empty())
	{
		cout << '\t' << g.top();
		g.pop();
	}
	cout << '\n';
}

//Function to reverse the queue 
void reverseQueue(priority_queue <int> queue)
{
	int* front = const_cast<int*>(&queue.top());
	int* back = const_cast<int*>(front + queue.size());
	std::sort(front, back);
	while (front < back)
	{
		printf("%i ", *front);
		++front;
	}
}

//Function to clear the priority queue
template <class Q>
void clearQueue(Q & q)
{
	q = Q();
}

//Function to remove the first item from the queue
void removeNumber(priority_queue <int> queue)
{
	queue.pop();
	showPQ(queue);
}

//Function to add an item to the queue
void addNumber(priority_queue <int> queue)
{
	int x;
	cout << "Enter a new number into the queue.\n";
	cin >> x;
	queue.push(x);
	cout << "Your number has been added to the queue.\n";
	showPQ(queue);
}

//Function to execute order 66
// It takes each item in the queue to spell out STAR WARS 
// Only works with single digit numbers.
void ORDER66(priority_queue <int> queue)
{
	SetConsoleTextAttribute(screen, 14);

	//S
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << queue.top() << endl;
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << "        " << queue.top() << endl;
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl << endl;
	//T
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << "    " << queue.top() << endl;
	cout << "    " << queue.top() << endl;
	cout << "    " << queue.top() << endl;
	cout << "    " << queue.top() << endl << endl;

	queue.pop();
	//A
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << queue.top() << "       " << queue.top() << endl;
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << queue.top() << "       " << queue.top() << endl;
	cout << queue.top() << "       " << queue.top() << endl << endl;
	//R
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << queue.top() << "       " << queue.top() << endl;
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << queue.top() << "   " << queue.top() << endl;
	cout << queue.top() << "      " << queue.top() << endl << endl << endl;

	queue.pop();
	//W
	cout << queue.top() << "       " << queue.top() << endl;
	cout << queue.top() << "       " << queue.top() << endl;
	cout << queue.top() << "   " << queue.top() << "   " << queue.top() << endl;
	cout << queue.top() << "   " << queue.top() << "   " << queue.top() << endl;
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl << endl;
	//A
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << queue.top() << "       " << queue.top() << endl;
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << queue.top() << "       " << queue.top() << endl;
	cout << queue.top() << "       " << queue.top() << endl << endl;

	queue.pop();
	//R
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << queue.top() << "       " << queue.top() << endl;
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << queue.top() << "   " << queue.top() << endl;
	cout << queue.top() << "      " << queue.top() << endl << endl;
	//S
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << queue.top() << endl;
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl;
	cout << "        " << queue.top() << endl;
	cout << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << " " << queue.top() << endl << endl;


	cout << endl << endl;
}