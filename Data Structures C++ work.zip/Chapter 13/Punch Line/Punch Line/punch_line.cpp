/*Punch Line
This is a program that reads and prints a joke and its punch line from two different files. The main function of this program will open the two files and -
then call two functions, passing each one the file it needs. The first function will read and display each line in the file it is passed (the joke file).
The second function will display only the last line of the file it is passed (the punch line file). It will find this line by seeking to the end of the - 
file and then backing up to the beginning of the last line.
Benjamin Costello
*/

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

//Function prototypes
void readJokeFile(ifstream &inFile);
void readPunchLineFile(ifstream &infile);

int main()
{
	//Variables needed for file input
	ifstream jokeFile;
	ifstream punchLineFile;

	//Open the files
	jokeFile.open("joke.txt");
	punchLineFile.open("punchline.txt");

	//Check if the files were opened successfully
	if (!jokeFile || !punchLineFile)
	{
		cout << "One of the files could not be opened!" << endl;
		system("pause");
		return 0;
	}

	//Call the readJokeFile function
	readJokeFile(jokeFile);

	//Call the readPunchLineFile function
	readPunchLineFile(punchLineFile);

	system("pause");
	return 0;
}

//Function to read and display the joke file
void readJokeFile(ifstream &inFile)
{
	while (inFile) //Print all lines in the joke.txt
	{
		string line;
		getline(inFile, line);
		cout << line << endl;
	}
}

// Function to read and display the punch line file
void readPunchLineFile(ifstream &infile)
{
	if (infile) //Print only the last line in the punchline.txt
	{
		infile.seekg(-1, ios_base::end); //Start at the last character before the end of file (eof)
		char ch = ' ';
		while (ch != '\n')
		{
			infile.seekg(-2, ios_base::cur); //Now go two steps back, not checking the last character
			if ((int)infile.tellg() <= 0) //If we are past the start of the file, this is now the start of the line
			{
				infile.seekg(0);
				break;
			}
			infile.get(ch); //Do check on the following character
		}
		string lastLine;
		getline(infile, lastLine);
		cout << lastLine << endl; 
		cout << endl;
	}
}