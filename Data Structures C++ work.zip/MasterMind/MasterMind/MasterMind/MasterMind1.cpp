//Benjamin Costello & Edgard J. Flores
/*MASTERMIND
This is a simple code-breaking board game for two players, invented in 1970 by Mordecai Meirowitz. The general idea is that one player becomes - 
the code maker and the second becomes the code breaker. The code maker will decide on a code. The code is made up of four colors.
The code breaker will have 10 attempts at trying to break the code and guess the correct colors in the correct spots. If the code breaker - 
runs out of attempts he/she loses the game. If they guess all the colors and in the correct spots, he/she wins the game!
*/
#include <iostream>
#include <string>
#include <iomanip>
#include <windows.h>
#include <stdio.h>
#include "MasterMind.h"

using namespace std;
static string Colors[4]; 

void Player1() // Input for Player1's MasterMind Code.
{
	string YoN;
	cout << "Player 1\n" << "Please enter the color for slot 1:\n";
	cin >> Colors[0];
	
	while (Colors[0] != "Red" && Colors[0] != "Blue" && Colors[0] != "Green" && Colors[0] != "Yellow")
	{
		cout << "Please enter either Red, Blue, Green, or Yellow for slot 1.\n";
		cin >> Colors[0];
	}
	cout << "Please enter the color for slot 2:\n";
	cin >> Colors[1];
	while (Colors[1] != "Red" && Colors[1] != "Blue" && Colors[1] != "Green" && Colors[1] != "Yellow")
	{
		cout << "Please enter either Red, Blue, Green, or Yellow for slot 2.\n";
		cin >> Colors[1];
	}
	cout << "Please enter the color for slot 3:\n";
	cin >> Colors[2];
	while (Colors[2] != "Red" && Colors[2] != "Blue" && Colors[2] != "Green" && Colors[2] != "Yellow")
	{
		cout << "Please enter either Red, Blue, Green, or Yellow for slot 3.\n";
		cin >> Colors[2];
	}
	cout << "Please enter the color for slot 4:\n";
	cin >> Colors[3];
	while (Colors[3] != "Red" && Colors[3] != "Blue" && Colors[3] != "Green" && Colors[3] != "Yellow")
	{
		cout << "Please enter either Red, Blue, Green, or Yellow for slot 4.\n";
		cin >> Colors[3];
	}
	cout << endl;
	cout << Colors[0] << " " << Colors[1] << " " << Colors[2] << " " << Colors[3] << endl;
	cout << "Is this the code you wish to enter? Yes or No.\n"; // Checks if Player1 is ready to end his/her turn.
	cin >> YoN;
	while (YoN != "Yes" && YoN != "No")
	{
		cout << "Please enter Yes or No.\n";
		cin >> YoN;
	}
	if (YoN == "No") 
	{
		Player1();
	}
}
HANDLE screen = GetStdHandle(STD_OUTPUT_HANDLE);

//Player2 function to get the guesses from the second player who is trying to break the code
void Player2(static string &Colors, string *guess1, string *guess2, string *guess3, string *guess4)
{
		cout << "Player 2\n";
		cout << "Input your first guess:" << endl;
		cin >> *guess1;
		//cout << "guess1 is: " << *guess1 << " DEBUGGING" << endl; //DEBUGGING

		cout << "Input your second guess:" << endl;
		cin >> *guess2;
		//cout << "guess2 is: " << *guess2 << " DEBUGGING" << endl; //DEBUGGING

		cout << "Input your third guess:" << endl;
		cin >> *guess3;
		//cout << "guess3 is: " << *guess3 << " DEBUGGING" << endl; //DEBUGGING

		cout << "Input your fourth guess:" << endl;
		cin >> *guess4;
		//cout << "guess4 is: " << *guess4 << " DEBUGGING" << endl; //DEBUGGING
}

//checkGuess1 function to check Player2's first guess, if it is correct, and what slot it is correct in
void checkGuess1(string &guess1)
{
	if (guess1 == Colors[0])
	{
		cout << "First guess " << guess1 << " in slot 1 is correct." << endl;
	}
	else
	{
		cout << "First guess " << guess1 << " in slot 1 is incorrect." << endl;
	}
}

//checkGuess2 function to check Player2's second guess, if it is correct, and what slot it is correct in
void checkGuess2(string &guess2)
{
	if (guess2 == Colors[1])
	{
		cout << "Second guess " << guess2 << " in slot 2 is correct." << endl;
	}
	else
	{
		cout << "Second guess " << guess2 << " in slot 2 is incorrect." << endl;
	}
}

//checkGuess3 function to check Player2's third guess, if it is correct, and what slot it is correct in
void checkGuess3(string &guess3)
{
	if (guess3 == Colors[2])
	{
		cout << "Third guess " << guess3 << " in slot 3 is correct." << endl;
	}
	else
	{
		cout << "Third guess " << guess3 << " in slot 3 is incorrect." << endl;
	}
}

//checkGuess4 function to check Player2's fourth guess, if it is correct, and what slot it is correct in
void checkGuess4(string &guess4)
{
	if (guess4 == Colors[3])
	{
		cout << "Fourth guess " << guess4 << " in slot 4 is correct." << endl;
	}
	else
	{
		cout << "Fourth guess " << guess4 << " in slot 4 is incorrect." << endl;
	}
}

int main()
{
	MasterMind mm; //MasterMind class object

	string guess1, guess2, guess3, guess4;
	bool win = false;
	int attempts = 10; //Number of attempts for Player2 to guess the color code
	SetConsoleTextAttribute(screen, 11);
	cout << "MASTERMIND" << endl;
	SetConsoleTextAttribute(screen, 14);
	Player1();
	mm.ClearScreen();
	do
	{
		Player2(*Colors, &guess1, &guess2, &guess3, &guess4);
		mm.ClearScreen();
		cout << "Your code entered: " << guess1 << " " << guess2 << " " << guess3 << " " << guess4 << endl;
		checkGuess1(guess1);
		checkGuess2(guess2);
		checkGuess3(guess3);
		checkGuess4(guess4);
		cout << endl;
		attempts--; //Decrease the amount of attempts Player2 has by 1 each set of guesses
		cout << "You have " << attempts << " attempts left to break the code." << endl;
		cout << endl;

		//Check if Player2 has won
		if (guess1 == Colors[0] && guess2 == Colors[1] && guess3 == Colors[2] && guess4 == Colors[3])
		{
			mm.ClearScreen();
			win = true;
			SetConsoleTextAttribute(screen, 2);
			cout << "Congratulations! You broke the code!" << endl;
			cout << Colors[0] << " " << Colors[1] << " " << Colors[2] << " " << Colors[3] << endl;
			system("pause");
			return 0;
		}

		//Check if Player2 has 0 attempts left to guess the color code
		if (attempts == 0)
		{
			mm.ClearScreen();
			SetConsoleTextAttribute(screen, 12);
			cout << "Sorry, but you ran out of attempts. Game Over!" << endl;
			system("pause");
			return 0;
		}

	} while (win != true);
	mm.ClearScreen();

	system("pause");
	return 0;
}