/*Balanced Parentheses
This is a program that uses a stacl tp determine whether a string entered at the keyboard has balanced parentheses.
Benjamin Costello
*/

#include <iostream>
#include <stack>
#include <string>
using namespace std;

//Function prototypes
bool brackets(char open, char closed);
bool balancedParentheses(string b);


int main()
{
	//Get the expression from the user
	string input;
	cout << "Enter an expression: ";
	cin >> input;

	//Now check for balance using the balancedParentheses function with the user's input
	if (balancedParentheses(input))
	{
		cout << "This expression has balanced parentheses!" << endl;
	}
	else
	{
		cout << "This expression does not have balanced parentheses." << endl;
	}

	system("pause");
	return 0;
}

//brackets function to check if two characters are opening and closing an expression
bool brackets(char open, char closed)
{
	if (open == '(' && closed == ')')
	{
		return true;
	}
	else if (open == '[' && closed == ']')
	{
		return true;
	}
	else if (open == '{' && closed == '}')
	{
		return true;
	}
	return false;
}

//balancedParentheses function to check for balanced parentheses
bool balancedParentheses(string b)
{
	stack<char> a;
	for (int i = 0; i < b.length(); i++)
	{
		if (b[i] == '(' || b[i] == '{' || b[i] == '[')
			a.push(b[i]);
		else if (b[i] == ')' || b[i] == '}' || b[i] == ']')
		{
			if (a.empty() || !brackets(a.top(), b[i]))
				return false;
			else
				a.pop();
		}
	}
	return a.empty();
}