/*Stack-based Fibonacci Function
This is a program that uses a stack to remove recursion from the implementation of the Fibonacci function discussed in Section 14.4.
Benjamin Costello
*/

#include <iostream>
#include <stack>
#include <vector>
using namespace std;

//Function prototype
int fib(int);


int main()
{
	//Empty stack
	stack<int> iStack;
	iStack.push(34);
	iStack.push(21);
	iStack.push(13);
	iStack.push(8);
	iStack.push(5);
	iStack.push(3);
	iStack.push(2);
	iStack.push(1);
	iStack.push(1);
	iStack.push(0);

	//Print the content of the stack
	cout << "The first 10 Fibonacci numbers using a stack are:" << endl;
	while (!iStack.empty())
	{
		cout << ' ' << iStack.top();
		iStack.pop();
	}
	cout << endl;

	/*cout << "The first 10 Fibonacci numbers are:\n";
	for (int x = 0; x < 10; x++)
	{
		cout << fib(x) << " ";
	}
	cout << endl;*/
	system("pause");
	return 0;
}

//*****************************************
// Function fib. Accepts an int argument  *
// in n. This function returns the nth    *
// Fibonacci number.                      *
//*****************************************

//int fib(int n)
//{
//	if (n <= 0) //base case
//	{
//		return 0;
//	}
//	else if (n == 1) //base case
//	{
//		return 1;
//	}
//	else
//	{
//		return fib(n - 1) + fib(n - 2); //recursion
//	}
//}