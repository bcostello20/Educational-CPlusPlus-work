/*Algorithm Workbench #20
Benjamin Costello
*/


#include <iostream>
using namespace std;

const int size = 5; //To get 5 numbers

// Base Abstract Class
class Base
{
protected:
	int array[::size]; //An array of 5 integers
	int index;

public:
	Base();
	virtual bool compare(int, int) = 0;
	void setValues(int);
	void printArray();
	void sort();
};

// Ascending Derived Class
class Ascending :public Base
{
public:
	virtual bool compare(int, int);
};

// Descending Derived Class
class Descending :public Base
{
public:
	virtual bool compare(int, int);
};



// Constructor
Base::Base()
{
	for (int x = 0; x < ::size; x++)
	{
		array[x] = 0;
	}

	index = 0;
}

// Compare function for the Ascending class
bool Ascending::compare(int x, int y)
{
	if (x > y)
	{
		return true;
	}
	else
	{
		return false;
	}
}

// Compare function for the Descending class
bool Descending::compare(int x, int y)
{
	if (x < y)
	{
		return true;
	}
	else
	{
		return false;
	}
}

// Sort Member Function
void Base::sort()
{
	int temp;
	bool swap;

	do
	{
		swap = false;

		for (int x = 0; x < ::size - 1; x++)
		{
			if (compare(array[x], array[x + 1]))
			{
				temp = array[x];
				array[x] = array[x + 1];
				array[x + 1] = temp;
				swap = true;
			}
		}
	} while (swap);
}


// Set values function
void Base::setValues(int val)
{
	if (index < ::size)
	{
		array[index] = val;
		index++;
	}
}

// Print function
void Base::printArray()
{
	for (int x = 0; x < ::size; x++)
	{
		cout << array[x] << endl;
	}
}


int main()
{
	Base* test[] = { new Ascending, new Descending };


	// Setting values for both objects
	int value;
	for (int x = 0; x < 2; x++)
	{
		for (int y = 0; y < ::size; y++)
		{
			cout << "Enter a number: ";
			cin >> value;

			test[x]->setValues(value);
		}
		cout << endl;
	}

	//Do the displays
	cout << "Printing original Ascending" << endl;
	test[0]->printArray();
	cout << endl << "Printing Ascending sorted" << endl;
	test[0]->sort();
	test[0]->printArray();

	cout << endl << endl << "Printing original Descending" << endl;
	test[1]->printArray();
	cout << endl << "Printing Descending sorted" << endl;
	test[1]->sort();
	test[1]->printArray();

	system("pause");
	return 0;
}