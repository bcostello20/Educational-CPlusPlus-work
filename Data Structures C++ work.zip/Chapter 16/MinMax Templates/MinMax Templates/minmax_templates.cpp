/*Min/Max Templates
This is a program with two functions min and max. min accepts two arguments and returns the value of the argument that is the lesser of the two. max accepts two -
arguments and returns the value of the argument that is the greatest of the two.
Benjamin Costello
*/


#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

//min template function to accept two arguments and return the lesser value
template <typename T>
T min(T first, T second)
{
	if (first < second)
	{
		return first;
	}
	else
	{
		return second;
	}
}

//max template function to accept two arguments and return the greater value
template <typename T>
T max(T first, T second)
{
	if (first > second)
	{
		return first;
	}
	else
	{
		return second;
	}
}

int main()
{
	int num1, num2;
	double number1, number2;
	string string1, string2;

	//Get integers from the user
	cout << "Enter two integers separated by a space: ";
	cin >> num1 >> num2;

	//Call the min and max functions for the integers
	cout << "Lesser value: " << min(num1, num2) << endl;
	cout << "Greater value: " << max(num1, num2) << endl;

	//Get doubles from the user
	cout << "Enter two floating values separated by a space: ";
	cin >> number1 >> number2;

	//Call the min and max functions for the doubles
	cout << fixed << showpoint << setprecision(2);
	cout << "Lesser value: " << min(number1, number2) << endl;
	cout << "Greater value: " << max(number1, number2) << endl;

	//Get strings from the user
	cout << "Enter two strings separated by a space: ";
	cin >> string1 >> string2;

	//Call the min and max functions for the strings
	cout << "Lesser value: " << min(string1, string2) << endl;
	cout << "Greater value: " << max(string1, string2) << endl;

	system("pause");
	return 0;
}	