/*Vacation Days
Benjamin Costello
This is program that prompts the users to enter the number of days they plan to spend on their next vacation. Then computes and and reports how long that is in hours, in minutes, and in seconds.
*/

#include <iostream>
#include <iomanip>
using namespace std;



int main()
{
	int number_of_days_on_vacation;
	int hours = 24;
	int minutes = 1440;
	int seconds = 86400;

	int to_hours;
	int to_minutes;
	int to_seconds;



	// Ask the user to enter the number of days they plan to spend on their next vacation.
	cout << "How many days do you plan to spend on vacation?: ";
	cin >> number_of_days_on_vacation;


	// Compute and report how long it is in hours, minutes, and in seconds.
	to_hours = number_of_days_on_vacation * hours;
	to_minutes = number_of_days_on_vacation * minutes;
	to_seconds = number_of_days_on_vacation * seconds;

	cout << "You will be on vacation for " << to_hours << " hours " << to_minutes << " minutes" << " and " << to_seconds << " seconds." << endl;


	system("pause");

	return 0;
}