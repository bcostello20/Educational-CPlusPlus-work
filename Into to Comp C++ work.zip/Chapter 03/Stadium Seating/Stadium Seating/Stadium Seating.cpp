/*Stadium Seating
Benjamin Costello
This is a program that asks how many tickets for each class of seats were sold, then displays the amount of income generated from ticket sales.
*/

#include <iostream>
#include <iomanip>
using namespace std;



int main()
{
	double Class_A = 15.00;
	double Class_B = 12.00;
	double Class_C = 9.00;
	
	int Class_A_Seats;
	int Class_B_Seats;
	int Class_C_Seats;

	double total_sales;


	// Ask how many tickets for each class of seats were sold
	cout << "How many Class A tickets were sold?: ";
	cin >> Class_A_Seats;

	cout << "How many Class B tickets were sold?: ";
	cin >> Class_B_Seats;

	cout << "How many Class C tickets were sold?: ";
	cin >> Class_C_Seats;


	// Calculate and display the income generated from ticket sales
	total_sales = Class_A_Seats * Class_A + Class_B_Seats * Class_B + Class_C_Seats * Class_C;

	cout << "The total income from ticket sales is: $" << fixed << setprecision(2) << total_sales << endl;


	system("pause");

	return 0;
}