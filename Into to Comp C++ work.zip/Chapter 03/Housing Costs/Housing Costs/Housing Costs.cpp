/*Housing Costs
Benjamin Costello
This is a program that asks the user to enter their monthly costs for each of the following housing expenses:
�	rent of mortgage payment
�	utilities
�	phones
�	cable
The program should display the total monthly cost of these expenses and the total annual cost of these expenses.
*/


#include <iostream>
#include <iomanip>
using namespace std;



int main()
{
	double mortgage_payment;
	double utilities_payment;
	double phones_payment;
	double cable_payment;

	double monthly_cost;
	double annual_cost;


	// Ask the user to enter their monthly costs for each of the housing expenses.
	cout << "Enter your monthly costs for Mortgage, Utilities, Phones and Cable  \nseparated by a space: ";
	cin >> mortgage_payment >> utilities_payment >> phones_payment >> cable_payment;

	// Calculate and display the total monthly cost of these expenses.
	monthly_cost = mortgage_payment + utilities_payment + phones_payment + cable_payment;
	annual_cost = (mortgage_payment + utilities_payment + phones_payment + cable_payment) * 12;

	cout << "The total monthly cost is: $" << showpoint  << monthly_cost << endl;
	cout << "The total annual cost is: $" << fixed << showpoint << setprecision(2) << annual_cost << endl;


	system("pause");

	return 0;
}