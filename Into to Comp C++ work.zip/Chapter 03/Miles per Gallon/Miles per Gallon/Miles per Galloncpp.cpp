/*Miles per Gallon
Benjamin Costello
This is a program that calculates a car�s gas mileage.  The program should ask the user to enter the number of gallons of gas the car can hold and the number of miles it can be driven on a full tank.
It should then calculate and display the number of miles per gallon the car gets.
*/

#include <iostream>
using namespace std;



int main()
{
	int gallons_car_can_hold;
	int number_of_miles_driven_on_full_tank;
	int mpg;



	// Ask the user to enter the number of gallons of gas the car can hold and number of miles it can be driven on a full tank.
	cout << "Enter number of gallons of gas the car can hold and number of miles it can be driven on a full tank \nseparated by a space: ";
	cin >> gallons_car_can_hold >> number_of_miles_driven_on_full_tank;

	// Calculate and display the number of miles per gallon the car gets.
	mpg = number_of_miles_driven_on_full_tank / gallons_car_can_hold;
	cout << "The car gets " << mpg << " miles per gallon." << endl;

	system("pause");

		return 0;
}