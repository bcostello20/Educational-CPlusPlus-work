/*Magic Dates
Benjamin Costello
This is a program that asks the user to enter a month, day and 2-digit year (as integers).  
The program then determines whether the entered date is magic by multiplying the month by the day and testing the result to see if it equals the year.  
Then displays a message indicating whether the date is magic or not magic.
*/


#include <iostream>
using namespace std;



int main()
{
	int month, day, year;

	int magic_date;

	// Ask the user to enter month, day and 2-digit year (as integers).
	cout << "Enter the month, day and 2-digit year separated by a space: ";
	cin >> month >> day >> year;

	// Determine whether the date is magic by multiplying the month by the day and test the result to see if it equals the year.
	magic_date = month * day;

	if (magic_date == year)
	{
		cout << "This is a magic date." << endl;
	}
	else
	{
		cout << "This is not a magic date." << endl;
	}

	system("pause");

	return 0;
}