/*Color Mixer
Benjamin Costello
This is a program that asks the user to enter the names of two primary colors to mix.  If the user enters anything other than red, blue, or yellow, the program should display an error message and end. -- 
Otherwise, the program will display the name of the secondary color that results.
*/


#include <iostream>
#include <string>
using namespace std;



int main()
{
	const string RED = "red";
	const string BLUE = "blue";
	const string YELLOW = "yellow";
	string prim1, prim2;


	// Ask the user to enter the names of two primary colors to mix.
	cout << "Enter the names of two primary colors (red, blue, yellow) separated by a space: ";
	cin >> prim1 >> prim2;

	// Compute and displays.
	if (prim1 == RED && prim2 == BLUE || prim1 == BLUE && prim2 == RED)
	{
		cout << "The resulting secondary color is purple." << endl;
	}
	else if (prim1 == RED && prim2 == YELLOW || prim1 == YELLOW && prim2 == RED)
	{
		cout << "The resulting secondary color is orange." << endl;
	}
	else if (prim1 == BLUE && prim2 == YELLOW || prim1 == YELLOW && prim2 == BLUE)
	{
		cout << "The resulting secondary color is green." << endl;
	}
	else
	{
		cout << "You did not enter a primary color for one or both colors, restart the program and try again." << endl;
	}


	system("pause");

	return 0;
}