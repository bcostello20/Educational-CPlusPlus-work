/*Minimum/Maximum
Benjamin Costello
This is a program that asks the user to enter two numbers.  The program uses the conditional operator to determine which is the smaller and which is the larger.
*/

#include <iostream>
using namespace std;



int main()
{
	int num1, num2;

	// Ask the user to enter two numbers.
	cout << "Enter two numbers separated by a space: ";
	cin >> num1 >> num2;

	// Determine which is smaller and which is larger.
	if (num1 < num2)
	{
		cout << num2 << " is greater than " << num1 << endl;
	}
	else if (num2 < num1)
	{
		cout << num1 << " is greater than " << num2 << endl;
	}
	else if (num1 == num2)
	{
		cout << "The numbers are equal. Enter two different numbers after restarting the program." << endl;
	}
	else
	{
		cout << "Invalid input, try again." << endl;
	}

	system("pause");

	return 0;
}