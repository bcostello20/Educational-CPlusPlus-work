/*Fat Gram Calculator
Benjamin Costello
This is a program that asks for the number of calories and fat grams in a food. The program then displays the percentage of calories that come from fat.
If the calories from fat are less than 30 percent of the total calories of the food, it will display a message indicating the food is low in fat.
*/


#include <iostream>
using namespace std;




int main()
{
	double calories, fat_grams, calories_from_fat, calories_percentage_from_fat, low_in_fat;


	// Ask the user for the number of calories and fat grams in a food.
	cout << "Enter number of calories and fat grams from the food separated by a space: ";
	cin >> calories >> fat_grams;

	calories_from_fat = fat_grams * 9;

	// Compute and display the percentage of calories from fat.
	if ((calories > 0) && (fat_grams >= 0) && (calories_from_fat < calories)) // Input validation check.
	{
		calories_percentage_from_fat = calories_from_fat / calories;
		cout << "The percentage of calories from fat is: " << calories_percentage_from_fat << "%" << endl;

		// Is it low in fat?
		if (calories_from_fat < calories*.3)
		{
			cout << "The food is low in fat." << endl;
		}
	}
	else
	{
		cout << "Invalid input. Restart the program and try again." << endl; // If the input does not validate this will be shown.
	}
	


	system("pause");

	return 0;
}