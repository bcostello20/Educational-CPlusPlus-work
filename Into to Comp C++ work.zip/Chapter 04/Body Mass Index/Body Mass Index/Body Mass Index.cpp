/*Body Mass Index
Benjamin Costello
This is a program that calculates and displays a person's body mass index (BMI). The BMI is often used to determine whether a person with a sedentary lifestyle ---
is overweight or underweight for his or her height.
Formula: BMI = weight x 703/height^2 -- where weight is measured in pounds and height is measured in inches.
This program will display a message indicating whether the person has optimal weight, is underweight, or is overweight.
*/


#include <iostream>
#include <cmath>
using namespace std;



int main()
{
	int weight, height;
	int bmi;


	// Ask the user for their weight and height.
	cout << "Enter your weight in pounds and height in inches separated by a space: ";
	cin >> weight >> height;

	// Compute the BMI.
	if (height > 0)
	{
		bmi = weight * 703 / pow(height, 2);

		// Displays using if/else.
		if (bmi >= 18.5 && bmi <= 25)
		{
			cout << "You have optimal weight." << endl;
		}
		else if (bmi < 18.5)
		{
			cout << "You are underweight." << endl;
		}
		else if (bmi > 25)
		{
			cout << "You are overweight." << endl;
		}
	}
	else // If the user enters 0 for the height this error will be shown.
	{
		cout << "Invalid input. Cannot divide by a height of 0. Restart the program and try again." << endl;
	}
	
	
	system("pause");

	return 0;
}