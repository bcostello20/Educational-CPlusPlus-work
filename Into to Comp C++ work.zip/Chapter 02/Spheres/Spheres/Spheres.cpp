/*Spheres
Benjamin Costello
This is a program to calculate and display the volume and surface area of a sphere.*/

#include <iostream>
using namespace std;



int main()
{
	float radius;
	double volume;
	double surface_area;


	// Ask the user to enter the radius of a sphere.
	cout << "Enter the radius of a sphere: ";
	cin >> radius;

	// Calculate the volume.
	volume = (1.333 * 3.14) * (radius * radius * radius);

	// Calculate the surface area.
	surface_area = 4.0 * 3.14 * (radius * radius);

	// Display the results.
	cout << "The radius is: " << radius << endl;
	cout << "The volume is: " << volume << endl;
	cout << "The surface area is: " << surface_area << endl;

	system("pause");
}