/*Stock Loss
Benjamin Costello
Kathryn bought 750 shares of stock at a price of $35.00 per share. A year later she sold them for just $31.15 per share.
This is a program that calculates and displays the following:
	- The total amount paid for the stock.
	- The total amount received from selling the stock.
	- The total amount of money she lost.
*/

#include <iostream>
using namespace std;



int main()
{
	int shares_bought = 750;
	double original_share_price = 35.00;
	double total_amount_for_stock;

	double amount_received;
	double shares_resold_price = 31.15;

	double amount_lost;

	// Get the total amount paid for the stock.
	total_amount_for_stock = original_share_price * shares_bought;

	// Get the amount received from selling the stock.
	amount_received = shares_resold_price * shares_bought;

	// Get the total amount of money she lost.
	amount_lost = total_amount_for_stock - amount_received;

	// Display the results.
	cout << "Total amount paid for the stock: $" << total_amount_for_stock << endl;
	cout << "Total amount received from selling: $" << amount_received << endl;
	cout << "Total amount of money lost: $" << amount_lost << endl;

	system("pause");

	return 0;
}