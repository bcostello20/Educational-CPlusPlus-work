/*Circuit Board Price
Benjamin Costello
An electronics company makes circuit boards that cost $14.95 each to produce. This is a program to determine how much the company should sell them for if it wants to make a 35% profit.
*/

#include <iostream>
using namespace std;



int main()
{
	double circuit_board = 14.95;
	double profit = 0.35;
	double calculate;
	double sell_for;

	// Compute and display the 35% profit for selling.
	calculate = circuit_board * profit; // equals 5.2325
	sell_for = calculate + circuit_board;
	cout << "Sell the circuit boards for $" << sell_for << " to make a 35% profit." << endl;

	system("pause");

	return 0;
}