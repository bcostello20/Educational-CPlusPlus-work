/*Restaurant Bill
Benjamin Costello
This a program that computes the tax and tip on a restaurant bill for a patron with a $44.50 meal charge.
*/

#include <iostream>
using namespace std;



int main()
{
	double meal_charge = 44.50;
	double tax = 0.0675;
	double after_tax;
	double tip = 0.15;
	double after_tip;
	double total_bill;

	// Display the meal cost.
	cout << "The meal cost is: $" << meal_charge << endl;

	// Display the tax amount.
	cout << "The tax amount is " << tax << "%" << endl;

	// Display the tip amount.
	cout << "The tip amount is " << tip << "%" << endl;

	// Compute and Display the total bill amount after tax and tip.
	after_tax = meal_charge * tax;
	total_bill = after_tax + meal_charge;
	after_tip = total_bill * tip;
	total_bill = total_bill + after_tip;
	cout << "The total bill is: $" << total_bill << endl;

	system("pause");

	return 0;
}