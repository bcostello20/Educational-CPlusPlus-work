/*Basketball Player Height
Benjamin Costello
This is a program to compute and display the height of a basketball player who is 74 inches tall in feet/inches form.
*/

#include <iostream>
using namespace std;



int main()
{
	int feet;
	int inches;


	// Compute the height.
	feet = 74 / 12;
	inches = 74 % 12;


	// Display the height in feet/inches form.
	cout << "The player is: " << feet << "\'" << inches << "\"" << endl;


	system("pause");

	return 0;
}