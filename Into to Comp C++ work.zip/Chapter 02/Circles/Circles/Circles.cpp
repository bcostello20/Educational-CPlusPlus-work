/*Circles
Benjamin Costello
This is a program that will get a circle's radius and the compute its area, circumference, and diameter.
*/

#include <iostream>
using namespace std;



int main()
{
	double radius;
	double area;
	double circumference;
	double diameter;

	// Ask the user for the circle's radius.
	cout << "Enter the radius of a circle: ";
	cin >> radius;

	// Compute the area.
	area = 3.14 * (radius * radius);

	// Compute the circumference.
	circumference = 2.0 * 3.14 * radius;

	// Compute the diameter.
	diameter = 2.0 * radius;

	// Display the radius.
	cout << "The radius is: " << radius << endl;

	// Display the diameter.
	cout << "The diameter is: " << diameter << endl;

	// Display the area.
	cout << "The area is: " << area << endl;

	// Display the circumference.
	cout << "The circumference is: " << circumference << endl;


	system("pause");
}