/*How Much Paint
Benjamin Costello
A particular brand of paint covers 340 square feet per gallon. This is a program to determine and report approximately how many gallons of paint will be needed to paint two coats on a ---
wooden fence that is 6 feet high and 100 feet long.
*/

#include <iostream>
using namespace std;



int main()
{
	int fence_height = 6;
	int fence_width = 100;
	int paint_covers = 340;
	int number_of_coats = 2;
	int gallons_mod;
	int gallons_needed;

	// Compute and Display gallons of paint needed for the fence.
	gallons_needed = fence_width * fence_height * number_of_coats / paint_covers;
	gallons_mod = fence_width * fence_height * number_of_coats % paint_covers;

	gallons_needed = (gallons_mod > 0) ? (gallons_needed + 1) : (gallons_needed);

	cout << "You will need " << gallons_needed << " gallons for painting the fence." << endl;

	system("pause");

	return 0;
}