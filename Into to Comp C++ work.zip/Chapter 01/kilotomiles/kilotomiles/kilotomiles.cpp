/// This is a program that will read in a number that represents the number of kilometers traveled. The output will convert this number to miles.

// Benjamin Costello

#include <iostream>
using namespace std;


int main()
{
	double kilostraveled, miles;
	double kilometerseachmile = 0.621;

	// Get the number of kilometers traveled.
	// 1 kilometer = 0.621 miles.
	cout << "Enter number of kilometers traveled: ";
	cin >> kilostraveled;

	// Convert kilos to miles.
	miles = kilostraveled * kilometerseachmile;

	// Display miles traveled.
	cout << "You traveled " << miles << " miles." << endl;

	system("pause");

	return 0;
}