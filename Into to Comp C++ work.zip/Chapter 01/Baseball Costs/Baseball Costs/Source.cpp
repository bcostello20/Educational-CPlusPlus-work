/// This program calculates how much a Little League baseball team spent last year to purchase new baseballs.

// Benjamin Costello

#include <iostream>
using namespace std;


int number_of_baseballs_purchased;
double cost_of_each_baseball;
double total;

int main()
{
	// Ask the user to enter the number of baseballs purchased.
	cout << "Enter number of baseballs purchased: ";
	cin >> number_of_baseballs_purchased;

	// Ask the user for the cost of each baseball.
	cout << "Enter the cost for each baseball: $";
	cin >> cost_of_each_baseball;

	// Calculate and display the total amount spent to purchase the baseballs.
	total = number_of_baseballs_purchased * cost_of_each_baseball;
	cout << "Total amount spent to purchase the baseballs is: $" << total << endl;

	system("pause");
}