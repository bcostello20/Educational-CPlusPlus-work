/// This program calculates how much a Little League baseball team spent last year to purchase new baseballs.

// Benjamin Costello

#include <iostream>
using namespace std;


double cost_of_soil;
double cost_of_flower_seeds;
double cost_of_fence;
double total;

int main()
{
	// Ask for the cost of soil.
	cout << "Enter cost of soil: $";
	cin >> cost_of_soil;

	// Ask for the cost of flower seeds.
	cout << "Enter the cost of flower seeds: $";
	cin >> cost_of_flower_seeds;

	// Ask for the cost of the fence.
	cout << "Enter the cost of the fence: $";
	cin >> cost_of_fence;

	// Calculate and display the total amount spent.
	total = cost_of_soil + cost_of_flower_seeds + cost_of_fence;
	cout << "The total amount spent is: $" << total << endl;

	system("pause");
}