/// This program calculates how much a student organization earns during its fund-raising candy sale.

// Benjamin Costello

#include <iostream>
using namespace std;


int candy_bars_sold;
int amount_earned_for_each_bar;
int total;

int main()
{
	// Ask the user to enter the number of candy bars sold.
	cout << "Enter number of candy bars sold: ";
	cin >> candy_bars_sold;

	// Ask the user for the amount earned for each candy bar sold.
	cout << "Enter amount earned for each candy bar sold: ";
	cin >> amount_earned_for_each_bar;

	// Calculate and display the total amount earned.
	total = amount_earned_for_each_bar * candy_bars_sold;
	cout << "The total amount earned is: $" << total << endl;

	system("pause");
}