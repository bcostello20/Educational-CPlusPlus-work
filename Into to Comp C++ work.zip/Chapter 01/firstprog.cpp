// This is the first program that just writes out a simple message
// Benjamin Costello

#include <iostream>               // needed to perform C++ I/O
using namespace std;

int main ()

{

	cout << "Now is the time for all good men" << endl;
	cout << "To come to the aid of their party" << endl;

	system("pause");

	return 0;

}