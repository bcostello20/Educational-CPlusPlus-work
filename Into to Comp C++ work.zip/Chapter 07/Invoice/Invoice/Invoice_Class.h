// This is the Invoice class specification file.
#pragma once

#ifndef INVOICE_CLASS_H
#define INVOICE_CLASS_H

#include <iostream>
#include <string>
#include <iomanip>

class Invoice
{
private:
	std::string partNum;	// Part number
	std::string partDescription;	// Part description
	int quantity;	// Quantity of item being purchased
	double price;	// Price per item

public:
	Invoice()
	{

	}
	Invoice(std::string pNum, std::string pDescription, int quant, double p)	// Constructor
	{
		partNum = pNum;
		partDescription = pDescription;
		quantity = quant;
		price = p;
	}
	// Set the part number
	void setPartNum(std::string pNum)
	{
		partNum = pNum;
	}
	// Get the part number
	std::string getPartNum()
	{
		return partNum;
	}
	// Set the part description
	void setPartDescription(std::string pDescription)
	{
		partDescription = pDescription;
	}
	// Get the part description
	std::string getPartDescription()
	{
		return partDescription;
	}
	// Set the quantity
	void setQuantity(int quant)
	{
		quantity = quant;
	}
	// Get the quantity
	int getQuantity()
	{
		return quantity;
	}
	// Set the price
	void setPrice(double p)
	{
		price = p;
	}
	// Get the price
	double getPrice()
	{
		return price;
	}
	// Get the invoice amount
	double getInvoiceAmount()
	{
		return quantity * price;
	}
};

#endif // !INVOICE_CLASS_H