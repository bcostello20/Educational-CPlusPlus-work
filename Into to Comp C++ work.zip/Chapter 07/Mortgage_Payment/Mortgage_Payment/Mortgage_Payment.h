/*Mortgage Payment
Benjamin Costello
This is a program to determine and calculate the monthly payment on a home mortgage.
*/
#pragma once
#include <cmath>

#ifndef MORTGAGE_PAYMENT_H
#define MORTGAGE_PAYMENT_H

class Payment
{
private:
	double Monthly_Payment, Loan, Rate, Term;
	int Years;

public:
	// Set the loan amount.
	void setLoanAmount(double L)
	{
		Loan = L;
	}
	// Set the interest rate.
	void setInterestRate(double r)
	{
		Rate = r / 100.0;
	}
	// Set the number of years of the loan.
	void setYearsOfLoan(double y)
	{
		Years = y;
	}
	// Return the monthly payment.
	double getMonthlyPayment()
	{
		calcTerm();
		Monthly_Payment = Loan * (Rate / 12) * Term / (Term - 1);
		return Monthly_Payment;
	}
	int calcTerm()
	{
		Term = pow((1 + ((Rate / 12))),(12 * Years));
		return Term;
	}
	// Return the total amount paid to the bank at the end of the loan.
	double getAmountToBank()
	{
		return (Monthly_Payment * (12 * Years));
	}
};

#endif // !MORTGAGE_PAYMENT_H
