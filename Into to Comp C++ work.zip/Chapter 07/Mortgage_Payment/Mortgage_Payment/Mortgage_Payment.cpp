/*Mortgage Payment
Benjamin Costello
This is a program to determine and calculate the monthly payment on a home mortgage.
*/


#include "Mortgage_Payment.h"
#include <iostream>
#include <iomanip>
using namespace std;



int main()
{
	// Define the Mortgage object.
	Payment mortgage;

	double /*payment,*/ loan, rate;
	int years;

	//// Ask the user to enter the data.
	//cout << "Enter monthly payment: ";
	//cin >> payment;

	cout << "Enter loan amount: ";
	cin >> loan;

	cout << "Enter interest rate: ";
	cin >> rate;

	cout << "Enter the number of years for the loan: ";
	cin >> years;

	// Call member functions to set the data.
	mortgage.setLoanAmount(loan);
	mortgage.setInterestRate(rate);
	mortgage.setYearsOfLoan(years);

	// Display the data.
	cout << fixed << showpoint << setprecision(2); // Fully format the output with 2 decimal places.
	cout << "\nHere is the Mortgage Payment:\n";
	cout << "The monthly payment is: $" << mortgage.getMonthlyPayment() << endl;
	cout << "Total amount paid to the bank is: $" << mortgage.getAmountToBank() << endl;

	system("pause");
	return 0;
}