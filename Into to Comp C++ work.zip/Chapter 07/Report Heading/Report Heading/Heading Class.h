// This is the Heading class specification file.

#pragma once

#include <iostream>
#include <iomanip>
#include <string>

#ifndef HEADING_CLASS_H
#define HEADING_CLASS_H

class Heading
{
private:
	std::string companyName, reportName;

public:
	Heading()	// Default constructor with default names
	{
		companyName = "ABC Industries";
		reportName = "Report";
	}
	Heading(std::string cName, std::string rName)	// Constructor with two parameters
	{
		companyName = cName;
		reportName = rName;
	}

	// Set company name
	std::string setCompanyName(std::string cName)
	{
		companyName = cName;
		return companyName;
	}

	// Set report name
	std::string setReportName(std::string rName)
	{
		reportName = rName;
		return reportName;
	}

	// Print the heading
	void printHeading()
	{
		std::cout << std::endl;
		std::cout.width(60);  std::cout << companyName << " " << reportName << std::endl;
	}
};

#endif // !HEADING_CLASS_H