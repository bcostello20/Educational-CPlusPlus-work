// This is the Widget class specification file.

#pragma once

#ifndef WIDGET_CLASS_H
#define WIDGET_CLASS_H

#include <iostream>

class Widget
{
private:
	int widgetsOrdered; // Number of widgets ordered
	const double producedEachHour = 10.0;
	const double hoursPerShift = 8.0;
	const double shiftsPerDay = 2.0;
	double amountToProduce = 0.0;
	
public:
	Widget()	// Default constructor
	{

	}

	// Set amount to produce
	void setAmountToProduce(double amount)
	{
		amountToProduce = amount;
	}
	// Get amount to produce
	double getAmountToProduce()
	{
		return amountToProduce;
	}
	// Get the number of days it will take to produce them
	double getDaysToProduceWidgets()
	{
		return (amountToProduce / (producedEachHour * hoursPerShift * shiftsPerDay));
	}
};

#endif // !WIDGET_CLASS_H