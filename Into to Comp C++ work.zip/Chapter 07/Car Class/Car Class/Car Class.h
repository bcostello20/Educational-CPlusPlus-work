// This is the Car class specification file.
#pragma once

#ifndef CAR_CLASS_H
#define CAR_CLASS_H

#include <iostream>
#include <string>


class Car
{
public:
	int year;	// The car's model year
	std::string make;	// The make of the car
	int speed;	// The car's current speed

	Car(int yr = 2016, std::string mk = "Unkown")	// Constructor with default parameters
	{
		year = yr;
		make = mk;
		speed = 0;
	}

	// Accessors
	// Get the objects year
	int getYear()
	{
		return year;
	}
	// Get the objects make
	std::string getMake()
	{
		return make;
	}
	// Get the objects speed
	int getSpeed()
	{
		return speed;
	}

	// Mutators
	// Accelerate
	void accelerate()
	{
		speed += 5;
	}
	// Brake
	void brake()
	{
		if (speed >= 5)
		{
			speed -= 5;
		}
		else
		{
			speed = 0;
		}
	}
};

#endif // !CAR_CLASS_H