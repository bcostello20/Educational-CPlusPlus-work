/*Circle Class
Benjamin Costello
This is a program the demonstrates the Circle class by asking the user for the circle�s radius, creating a Circle object, and then reporting the circle�s area, --
circumference, and diameter, fully formatted (2-decimal places) and labelled.
*/

#pragma once
#include <cmath>

#ifndef CIRCLE_CLASS_H

#define CIRCLE_CLASS_H

class Circle
{
private:
	double radius;
	const double pi = 3.14159;

public:
	// Default constructor - sets radius to 0.0.
	Circle()
	{
		radius = 0.0;
	}
	// Constructor - passes radius as an argument.
	Circle(double radius)
	{

	}
	// Initializes the radius member.
	void setRadius(double r)
	{
		radius = r;
	}
	// Returns the radius value.
	double getRadius()
	{
		return radius;
	}
	// Returns the area of the circle (area = pi * radius * radius).
	double getArea()
	{
		return pi * pow(radius, 2);
	}
	// Returns the diameter of the circle (radius * 2).
	double getDiameter()
	{
		return radius * 2;
	}
	// Returns the circumference of the circle (2 * pi * radius).
	double getCircumference()
	{
		return 2 * pi * radius;
	}

};

#endif // !CIRCLE_CLASS_H
