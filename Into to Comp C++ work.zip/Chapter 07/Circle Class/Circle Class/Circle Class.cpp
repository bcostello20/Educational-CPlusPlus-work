/*Circle Class
Benjamin Costello
This is a program the demonstrates the Circle class by asking the user for the circle�s radius, creating a Circle object, and then reporting the circle�s area, -- 
circumference, and diameter, fully formatted (2-decimal places) and labelled.
*/


#include "Circle Class.h"
#include <iostream>
#include <cmath>
#include <iomanip>
using  namespace std;


int main()
{
	// Define the Circle object.
	Circle circle1;

	double circleRadius;

	// Ask the user for the radius.
	cout << "Enter the radius of the circle: ";
	cin >> circleRadius;

	// Call member function to set circle radius.
	circle1.setRadius(circleRadius);

	// Call member functions to get circle information to display.
	cout << fixed << showpoint << setprecision(2); // Fully format the output to 2 decimal places.
	cout << "\nHere is the circle's data:\n";
	cout << "Area: " << circle1.getArea() << endl;
	cout << "Circumference: " << circle1.getCircumference() << endl;
	cout << "Diameter: " << circle1.getDiameter() << endl;

	system("pause");
	return 0;
}