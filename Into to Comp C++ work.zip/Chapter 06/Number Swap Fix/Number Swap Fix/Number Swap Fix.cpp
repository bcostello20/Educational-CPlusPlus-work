/*Number Swap
Benjamin Costello
This is a program that contains a function called swapNums.  This function takes two integer parameters, swaps them and outputs the results.
*/


#include <iostream>
using namespace std;

// Function prototype
void swapNums(int value1, int value2);


int main()
{
	int number1, number2;


	// Ask the user to enter two different numbers.
	cout << "Enter two different numbers separated by a space: ";
	cin >> number1 >> number2;

	// Output the numbers as entered.
	cout << "In main the two numbers are: " << number1 << " and " << number2 << endl;

	swapNums(number1, number2);

	cout << "Back in main the two numbers are: " << number1 << " and " << number2 << endl;


	system("pause");

	return 0;
}

void swapNums(int value1, int value2)
{
	int tempValue = value1;
	value1 = value2;
	value2 = tempValue;
	cout << "In swapNums, after swapping, the two numbers are: " << value1 << " and " << value2 << endl;
}