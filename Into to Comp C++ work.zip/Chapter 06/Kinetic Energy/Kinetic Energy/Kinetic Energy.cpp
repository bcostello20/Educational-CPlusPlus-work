/*Kinetic Energy
Benjamin Costello
This is a program that has a function named kineticEnergy that accepts an object's mass (in kilograms) and velocity (in meters per second) as arguments. The function will return the amount of kinetic --
energy that the object has.
*/


#include <iostream>
#include <cmath>
using namespace std;

// Function prototype
double kineticEnergy(double m, double v);


int main()
{
	double mass, velocity, result;

	// Ask the user to enter values for mass and velocity.
	cout << "Enter values for mass and velocity separated by a space: ";
	cin >> mass >> velocity;

	result = kineticEnergy(mass, velocity);

	cout << "The kinetic energy is " << result << "." << endl;

	system("pause");
	return 0;
}

double kineticEnergy(double m, double v)
{
	double ke = 0.5 * m * pow(v, 2);
	return ke;
}