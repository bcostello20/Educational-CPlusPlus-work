/*Vowels and Consonants
Benjamin Costello
This is a program that asks the user to input three different integers and will test them --
to see which are odd and which are even and if so, which is zero, using a function.
*/


#include <iostream>
using namespace std;

// Function prototype.
int numberStyle(int value1);


int main()
{
	int number1, number2, number3;

	// Ask the user to enter three different integers.
	cout << "Enter 3 integers separated by a space and press <Enter>: ";
	cin >> number1 >> number2 >> number3;

	int nums[] = { number1, number2, number3 };

	for (int i = 0; i < 3; i++)
	{
		if (numberStyle(nums[i]) == 0)
		{
			cout << "Integer " << nums[i] << " is zero." << endl;
		}
		else if (numberStyle(nums[i]) == 1)
		{
			cout << "Integer " << nums[i] << " is even." << endl;
		}
		else if (numberStyle(nums[i]) == -1)
		{
			cout << "Integer " << nums[i] << " is odd." << endl;
		}
	}


	system("pause");
	return 0;
}

int numberStyle(int value1)

{
	if (value1 == 0)
	{
		return 0;
	}
	else if (value1 % 2 == 0)
	{
		return 1;
	}
	else if (value1 % 2 != 0)
	{
		return -1;
	}
	return value1;
}

