/*isPrime Function
Benjamin Costello
This is a program that has a boolean function named isPrime, which takes an integer as an argument and returns true if the argument is a prime number, and false otherwise.
*/


#include <iostream>
using namespace std;


// Function prototype
bool isPrime(int value);


int main()
{
	int number, prime_or_not;

	// Ask the user to enter a number.
	cout << "Enter a number: ";
	cin >> number;

	if (number < 1)
	{
		cout << "Invalid input. Number must be 1 or higher. Restart the program." << endl;
	}
	else if (number == 2) // This is a boundary case and would fail the subfunction.
	{
		cout << number << " is not a prime number." << endl;
		system("pause");
		return 0;

	}

	// Function call.
	prime_or_not = isPrime(number);

	if (prime_or_not == true)
	{
		cout << number << " is a prime number." << endl;
	}
	else if (prime_or_not == false)
	{
		cout << number << " is not a prime number." << endl;
	}

	system("pause");

	return 0;
}

// isPrime function.
// parameters: int value
// outputs: bool
// This function determines if the number is prime.
bool isPrime(int value)
{
	for (int i = 2; i < value; i++)
	{
		if (value % i == 0)
		{
			return false;
		}
		else
		{
			continue;
		}
	}

	return true;
}