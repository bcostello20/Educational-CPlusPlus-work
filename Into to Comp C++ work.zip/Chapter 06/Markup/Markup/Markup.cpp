/*Markup
Benjamin Costello
This is a program that asks the user to enter an item's wholesale cost and its markup percentage. It will then display the item's retail price.
*/


#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;


// Function prototype
double calculateRetail(double ws_cost, double mup_percentage);


int main()
{
	double wholesale_cost, markup_percentage, retail_price;

	// Ask the user to enter an item's wholesale cost and its markup percentage.
	cout << "Enter the item's wholesale cost and markup percentage (0-100) separated by a space: ";
	cin >> wholesale_cost >> markup_percentage;

	if (markup_percentage < 0 || markup_percentage > 100)
	{
		cout << "Invalid markup percentage input. Restart the program." << endl;
		system("pause");
		return 1;
	}

	retail_price = calculateRetail(wholesale_cost, markup_percentage);

	cout << "The item's retail price is $" << showpoint << retail_price << endl;


	system("pause");

	return 0;
}

double calculateRetail(double ws_cost, double mup_percentage) // Calculate the retail price.
{
	double result = ws_cost + (ws_cost * (mup_percentage / 100.00));
	return result;
}