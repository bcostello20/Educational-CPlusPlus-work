/*Celsius Temperature Table
Benjamin Costello
This is a program with a function named celsius that accepts a Farenheit temperature as an argument and returns the temperature converted to Celsius.
*/


#include <iostream>
#include <iomanip>
using namespace std;

// Function prototype
double celsius(double temp);


int main()
{
	double in_celsius;

	cout << "	Fahrenheit		Celsius" << endl;

	for (double i = 0; i <= 20; i++)
	{
		in_celsius = celsius(i);
		cout <<	"	" << i << "			" << in_celsius << endl;
	}

	system("pause");

	return 0;
}

double celsius(double temp)
{
	double result = 0.55 * (temp - 32);
	return result;
}