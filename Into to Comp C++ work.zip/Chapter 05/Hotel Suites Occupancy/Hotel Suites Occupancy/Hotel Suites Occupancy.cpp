/*Hotel Suites Occupancy
Benjamin Costello
This is a program that calculates the occupancy rate of the 120 suites (20 per floor) located on the top six floors of a 15-story luxury hotel. These are floors 10-12 --
and 14-16.
*/


#include <iostream>
using namespace std;


int main()
{
	int floor;
	int suites_occupied;
	int percent_occupied;
	int total_suites_occupied = 0;


	// Ask the user to input the number of suites occupied on that floor.
	for (floor = 10; floor >= 10 && floor <= 16; floor++)
	{
		if (floor == 13)
		{
			continue;
		}

		cout << "Enter number of suites occupied on floor " << floor << ": ";
		cin >> suites_occupied;

		total_suites_occupied += suites_occupied;

		if (suites_occupied < 0 || suites_occupied > 20) // Input validation.
		{
			cout << "There are only 20 suites per floor. Please enter a value between 0-20." << endl;
			total_suites_occupied -= suites_occupied; // Subtract the wrong amount.
			floor--; // Decrement floor by 1.
		}
	}

	// Displays.
	cout << "The hotel has 120 suites." << endl;
	cout << "There are currently " << total_suites_occupied << " suites occupied." << endl;
	percent_occupied = total_suites_occupied * 100 / 120;
	cout << percent_occupied << "%" << " of the suites are occupied." << endl;
	


	system("pause");
	return 0;
}