/*Test Scores
Benjamin Costello
This is a program that uses a loop to ask the user to input a total of 5 test scores between 0 and 100 inclusive.  Tests each input and does not accept numbers out of range.  
Adds each valid test score to a total and computes the average to 2 decimal places after exiting the loop.  Displays the average score.
*/


#include <iostream>
#include <iomanip>
using namespace std;


int main()
{
	int testNum = 0; 
	int validTests = 0;
	double scoreSum = 0;
	double score;
	double average;

	// Use a loop to ask the user to input 5 test scores between 0 and 100.
	do
	{
		cout << "Enter a score for test " << testNum + 1 << ": ";
		cin >> score;
		testNum++;

		if (score < 0 || score > 100) // Input validation.
		{
			cout << "The number entered is out of range." << endl;
		}
		else
		{
			validTests++;
			scoreSum += score;
		}
	} 
	while (testNum < 5);

	
		average = scoreSum / validTests;
		cout << "The average score is: " << showpoint << setprecision(4) << average << endl;
	

	system("pause");
	return 0;
}