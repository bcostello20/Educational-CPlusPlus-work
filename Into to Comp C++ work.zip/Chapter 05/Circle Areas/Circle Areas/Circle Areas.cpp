/*Circle Areas
Benjamin Costello
This is a program that creates a table showing the radius and area for a circle whose radius begins with 1 and continues doubling until it is 8.
*/


#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;



int main()
{
	int counter = 1;
	double area;
	int radius = 1;
	double PI = acos(-1);

	// Display the table with information.
	cout << "   Circles     \n" << "Radius   Area  \n" << "-------------- \n";

	do
	{
		// Compute the area.
		area = PI * pow(radius, 2);
	
		cout << setw(4) << (radius) << setw(9) << (area) << endl;
		radius++;
	} 
	while (radius >= 1 && radius < 9);

	
	system("pause");
	return 0;
}