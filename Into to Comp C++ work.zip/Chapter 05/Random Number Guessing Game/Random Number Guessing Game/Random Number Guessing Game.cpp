/*Random Number Guessing Game
Benjamin Costello
This is a program that generates a random number between 1 and 100 and asks the user to guess what the number is. If the user's guess is higher than the random number, --
the program will display "Too high. Try again." If the user's guess is lower than the random number, the program will display "Too low. Try again."
*/


#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;


int main()
{
	unsigned Seed = time(0);
	int numberGuess;
	srand(Seed);
	int number = rand() % 100 + 1;

	do // Ask the user to guess the number.
	{
		cout << "What is the number?: ";
		cin >> numberGuess;

		if (numberGuess > number)
		{
			cout << "Too high. Try again." << endl;
		}
		else if (numberGuess < number)
		{
			cout << "Too low. Try again." << endl;
		}
		else if (numberGuess == number)
		{
			cout << "Congratulations. You figured out my number." << endl;
		}
	} 
	while (numberGuess != number);


	system("pause");
	return 0;
}