// This is the Batting Averages class specification file
#pragma once

#include <iostream>
#include <string>

#ifndef BATTING_AVERAGES_CLASS_H
#define BATTING_AVERAGES_CLASS_H

// Players class declaration
class Players
{
private:
	std::string name;	// Player's name
	double average;	// Player's average

public:
	Players()	// Default constructor
	{
		name = "ABC"; average = 0.0;
	}

	Players(std::string n, double a)	// 2 argument constructor
	{
		name = n;
		average = a;
	}

	// Get functions to retrieve member variable values
	std::string getName() const
	{
		std::string theName = name;
		return name;
	}

	double getAverage() const
	{
		return average;
	}
};

#endif // !BATTING_AVERAGES_CLASS_H
